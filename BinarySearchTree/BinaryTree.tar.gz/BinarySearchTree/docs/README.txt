Robert Loberg 0980340
Assignment Description: Text bot
How to Run: enter file directory and type "make" and then "./main" or "./testmain" for the testing of ADT.
Optional Features: None
Assumptions: None

Personalization: Program does not read in files (doc marks as necessary)
No functions work except add and quit. wrapped functions to other functions. (findInTree, removeFromTree, destroyTree,)
